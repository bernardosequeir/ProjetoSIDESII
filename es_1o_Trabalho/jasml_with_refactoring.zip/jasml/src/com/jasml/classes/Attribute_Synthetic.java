/*
 * Author jyang
 * Created on 2006-4-3 19:21:33
 */
package com.jasml.classes;

public class Attribute_Synthetic extends Attribute{
    public Attribute_Synthetic(){
        super(Constants.ATTRIBUTE_Synthetic,0 );       
    }

}
