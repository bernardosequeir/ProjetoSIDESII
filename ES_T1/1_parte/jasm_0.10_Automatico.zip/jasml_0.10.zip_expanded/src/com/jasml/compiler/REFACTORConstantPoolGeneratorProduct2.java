package com.jasml.compiler;


import java.util.HashMap;
import com.jasml.classes.ConstantPoolItem;
import com.jasml.classes.Constant_Float;
import com.jasml.classes.Constant_Integer;
import com.jasml.classes.Constant_Long;
import com.jasml.classes.Constant_Utf8;
import com.jasml.helper.Util;
import com.jasml.classes.Constant_Class;
import com.jasml.classes.Constant_NameAndType;
import com.jasml.classes.Constant_String;
import com.jasml.classes.Constants;
import com.jasml.classes.Constant_Double;

public class REFACTORConstantPoolGeneratorProduct2 {
	private HashMap classes = new HashMap();
	private HashMap strings = new HashMap();

	public int lookupClass(String className) {
		Object obj = classes.get(className);
		if (obj == null) {
			return -1;
		} else {
			return ((Integer) obj).intValue();
		}
	}

	public void ensureCapacity(ConstantPoolGenerator constantPoolGenerator) {
		constantPoolGenerator.ensureCapacity();
	}

	public int addFloat(float var, ConstantPoolGenerator constantPoolGenerator) {
		int index = lookupFloat(var, constantPoolGenerator);
		if (index == -1) {
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_Float(var);
			index = constantPoolGenerator.getCount();
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
		}
		return index;
	}

	public int addInteger(int var, ConstantPoolGenerator constantPoolGenerator) {
		int index = lookupInt(var, constantPoolGenerator);
		if (index == -1) {
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_Integer(var);
			index = constantPoolGenerator.getCount();
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
		}
		return index;
	}

	public int addLong(long var, ConstantPoolGenerator constantPoolGenerator) {
		int index = lookupLong(var, constantPoolGenerator);
		if (index == -1) {
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_Long(var);
			index = constantPoolGenerator.getCount();
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 2);
		}
		return index;
	}

	public int addUtf8(String s, ConstantPoolGenerator constantPoolGenerator) {
		int ret = constantPoolGenerator.lookupUtf8(s);
		if (ret == -1) {
			constantPoolGenerator.ensureCapacity();
			ConstantPoolItem item = new Constant_Utf8(s);
			ret = constantPoolGenerator.getCount();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount() + 1] = item;
		}
		return ret;
	}

	/**
	* this can be used to add a Constant_Class entry into constant pool. a constant class could be of a class type( like java/lang/Object), or of an array type of class(like [Ljava/lang/Object;), or array type of a primitive type(like [[I)
	* @param className  can be Strings like java.lang.Object, java.lang.Object[][], int[][].
	* @return
	*/
	public int addClass(String className, ConstantPoolGenerator constantPoolGenerator) {
		int index = 0;
		className = Util.toInnerClassName(className);
		index = lookupClass(className);
		if (index == -1) {
			int class_name_index = addUtf8(className, constantPoolGenerator);
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_Class(class_name_index);
			classes.put(className, new Integer(constantPoolGenerator.getCount()));
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
			return constantPoolGenerator.getCount();
		} else {
			return index;
		}
	}

	public int addFieldNameAndType(String name, String type, ConstantPoolGenerator constantPoolGenerator,
			HashMap thisNameTypes, REFACTORConstantPoolGeneratorProduct rEFACTORConstantPoolGeneratorProduct) {
		int name_index, type_index, index;
		type = Util.toInnerType(type);
		index = rEFACTORConstantPoolGeneratorProduct.lookupNameAndType(name + " " + type);
		if (index == -1) {
			name_index = addUtf8(name, constantPoolGenerator);
			type_index = addUtf8(type, constantPoolGenerator);
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_NameAndType(name_index,
					type_index);
			thisNameTypes.put(name + " " + type, new Integer(constantPoolGenerator.getCount()));
			index = constantPoolGenerator.getCount();
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
		}
		return index;
	}

	public int addMethodNameAndType(String name, String retType, String paras,
			ConstantPoolGenerator constantPoolGenerator, HashMap thisNameTypes,
			REFACTORConstantPoolGeneratorProduct rEFACTORConstantPoolGeneratorProduct) {
		int name_index, type_index, index;
		String type;
		retType = Util.toInnerType(retType);
		paras = Util.toInnerParameterTypes(paras);
		type = "(" + paras + ")" + retType;
		index = rEFACTORConstantPoolGeneratorProduct.lookupNameAndType(name + type);
		if (index == -1) {
			name_index = addUtf8(name, constantPoolGenerator);
			type_index = addUtf8(type, constantPoolGenerator);
			constantPoolGenerator.ensureCapacity();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = new Constant_NameAndType(name_index,
					type_index);
			thisNameTypes.put(name + type, new Integer(constantPoolGenerator.getCount()));
			index = constantPoolGenerator.getCount();
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
		}
		return index;
	}

	public int addString(String s, ConstantPoolGenerator constantPoolGenerator) {
		int ret = lookupString(s);
		if (ret == -1) {
			ConstantPoolItem item = new Constant_String(addUtf8(s, constantPoolGenerator));
			constantPoolGenerator.ensureCapacity();
			ret = constantPoolGenerator.getCount();
			constantPoolGenerator.getItems()[constantPoolGenerator.getCount()] = item;
			strings.put(s, new Integer(ret));
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 1);
		}
		return ret;
	}

	public int lookupString(String s) {
		Object obj = strings.get(s);
		if (obj != null) {
			return ((Integer) obj).intValue();
		}
		return -1;
	}

	public int lookupUtf8(String s, ConstantPoolGenerator constantPoolGenerator) {
		return constantPoolGenerator.lookupUtf8(s);
	}

	public int lookupDouble(double var, ConstantPoolGenerator constantPoolGenerator) {
		ConstantPoolItem item;
		for (int i = 0; i < constantPoolGenerator.getCount(); i++) {
			item = constantPoolGenerator.getItems()[i];
			if (item != null && item.tag == Constants.CONSTANT_Double && ((Constant_Double) item).value == var) {
				return i;
			}
		}
		return -1;
	}

	public int lookupInt(int var, ConstantPoolGenerator constantPoolGenerator) {
		ConstantPoolItem item;
		for (int i = 0; i < constantPoolGenerator.getCount(); i++) {
			item = constantPoolGenerator.getItems()[i];
			if (item != null && item.tag == Constants.CONSTANT_Integer && ((Constant_Integer) item).value == var) {
				return i;
			}
		}
		return -1;
	}

	public int lookupFloat(float var, ConstantPoolGenerator constantPoolGenerator) {
		ConstantPoolItem item;
		for (int i = 0; i < constantPoolGenerator.getCount(); i++) {
			item = constantPoolGenerator.getItems()[i];
			if (item != null && item.tag == Constants.CONSTANT_Float && ((Constant_Float) item).value == var) {
				return i;
			}
		}
		return -1;
	}

	public int lookupLong(long var, ConstantPoolGenerator constantPoolGenerator) {
		ConstantPoolItem item;
		for (int i = 0; i < constantPoolGenerator.getCount(); i++) {
			item = constantPoolGenerator.getItems()[i];
			if (item != null && item.tag == Constants.CONSTANT_Long && ((Constant_Long) item).value == var) {
				return i;
			}
		}
		return -1;
	}

	public int addDouble(double var, ConstantPoolItem[] thisItems, int thisCount,
			ConstantPoolGenerator constantPoolGenerator) {
		int index = lookupDouble(var, constantPoolGenerator);
		if (index == -1) {
			constantPoolGenerator.ensureCapacity();
			thisItems[thisCount] = new Constant_Double(var);
			index = thisCount;
			constantPoolGenerator.setCount(constantPoolGenerator.getCount() + 2);
		}
		return index;
	}
}