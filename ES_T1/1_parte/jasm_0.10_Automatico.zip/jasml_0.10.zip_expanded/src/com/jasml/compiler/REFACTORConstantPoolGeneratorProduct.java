package com.jasml.compiler;

import java.util.HashMap;
import com.jasml.classes.ConstantPool;
import com.jasml.classes.ConstantPoolItem;
import com.jasml.classes.Constant_Double;
import com.jasml.classes.Constant_Float;
import com.jasml.classes.Constant_Integer;
import com.jasml.classes.Constant_Long;
import com.jasml.classes.Constant_Utf8;
import com.jasml.helper.Util;
import com.jasml.classes.Constant_Class;
import com.jasml.classes.Constant_NameAndType;
import com.jasml.classes.Constant_String;
import com.jasml.classes.Constants;

public class REFACTORConstantPoolGeneratorProduct {
	private REFACTORConstantPoolGeneratorProduct2 rEFACTORConstantPoolGeneratorProduct2 = new REFACTORConstantPoolGeneratorProduct2();
	private HashMap nameTypes = new HashMap();
	public int lookupClass(String className) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupClass(className);
	}

	public ConstantPool getConstantPool(int thisCount, ConstantPoolItem[] thisItems) {
		ConstantPoolItem[] ret = new ConstantPoolItem[thisCount];
		System.arraycopy(thisItems, 0, ret, 0, thisCount);
		ConstantPool cpl = new ConstantPool(ret);
		return cpl;
	}

	public int addDouble(double var, ConstantPoolItem[] thisItems, int thisCount,
			ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addDouble(var, thisItems, thisCount, constantPoolGenerator);
	}

	public void ensureCapacity(ConstantPoolGenerator constantPoolGenerator) {
		rEFACTORConstantPoolGeneratorProduct2.ensureCapacity(constantPoolGenerator);
	}

	public int addFloat(float var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addFloat(var, constantPoolGenerator);
	}

	public int addInteger(int var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addInteger(var, constantPoolGenerator);
	}

	public int addLong(long var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addLong(var, constantPoolGenerator);
	}

	public int addUtf8(String s, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addUtf8(s, constantPoolGenerator);
	}

	/**
	 * this can be used to add a Constant_Class entry into constant pool. a constant
	 * class could be of a class type( like java/lang/Object), or of an array type
	 * of class(like [Ljava/lang/Object;), or array type of a primitive type(like
	 * [[I)
	 * 
	 * @param className can be Strings like java.lang.Object, java.lang.Object[][],
	 *                  int[][].
	 * @return
	 */
	public int addClass(String className, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addClass(className, constantPoolGenerator);
	}

	public int addFieldNameAndType(String name, String type, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addFieldNameAndType(name, type, constantPoolGenerator,
				this.nameTypes, this);
	}

	public int addMethodNameAndType(String name, String retType, String paras,
			ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addMethodNameAndType(name, retType, paras, constantPoolGenerator,
				this.nameTypes, this);
	}

	public int addString(String s, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.addString(s, constantPoolGenerator);
	}

	public int lookupString(String s) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupString(s);
	}

	public int lookupUtf8(String s, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupUtf8(s, constantPoolGenerator);
	}

	public int lookupDouble(double var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupDouble(var, constantPoolGenerator);
	}

	public int lookupInt(int var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupInt(var, constantPoolGenerator);
	}

	public int lookupFloat(float var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupFloat(var, constantPoolGenerator);
	}

	public int lookupLong(long var, ConstantPoolGenerator constantPoolGenerator) {
		return rEFACTORConstantPoolGeneratorProduct2.lookupLong(var, constantPoolGenerator);
	}

	public int lookupNameAndType(String nameType) {
		Object obj = nameTypes.get(nameType);
		if (obj == null) {
			return -1;
		} else {
			return ((Integer) obj).intValue();
		}
	}
}