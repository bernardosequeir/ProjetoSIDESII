/*
 * Author jyang
 * Created on 2006-4-7 11:08:44
 */
package com.jasml.compiler;

import java.util.HashMap;

import com.jasml.classes.*;
import com.jasml.helper.Util;


public class ConstantPoolGenerator {
	private REFACTORConstantPoolGeneratorProduct rEFACTORConstantPoolGeneratorProduct = new REFACTORConstantPoolGeneratorProduct();

	private ConstantPoolItem[] items;

	private int count = 1;

	private HashMap mifRef = new HashMap(); // methodRef, fieldRef, interfaceMethodRef

	public ConstantPoolGenerator() {
		items = new ConstantPoolItem[30];
		items[0] = new ConstantPoolItem((byte) 0);
	}

	public ConstantPool getConstantPool() {
		return rEFACTORConstantPoolGeneratorProduct.getConstantPool(this.count, this.items);
	}

	/**
	 * this can be used to add a Constant_Class entry into constant pool.
	 * a constant class could be of a class type( like java/lang/Object),
	 * or of an array type of class(like [Ljava/lang/Object;),
	 * or array type of a primitive type(like [[I)
	 * @param className can be Strings like java.lang.Object, java.lang.Object[][], int[][].
	 * @return
	 */
	public int addClass(String className) {
		return rEFACTORConstantPoolGeneratorProduct.addClass(className, this);

	}

	public int addDouble(double var) {
		return rEFACTORConstantPoolGeneratorProduct.addDouble(var, this.items, this.count, this);
	}

	public int addFieldref(String name, String className, String type) {
		int class_index, name_and_type_index, index;
		class_index = rEFACTORConstantPoolGeneratorProduct.addClass(className, this);
		name_and_type_index = rEFACTORConstantPoolGeneratorProduct.addFieldNameAndType(name, type, this);
		index = lookupMIFref("F_" + class_index + "_" + name_and_type_index);
		if (index == -1) {
			rEFACTORConstantPoolGeneratorProduct.ensureCapacity(this);
			items[count] = new Constant_Fieldref(class_index, name_and_type_index);
			mifRef.put("F_" + class_index + "_" + name_and_type_index, new Integer(count));
			index = count;
			count++;
		}
		return index;
	}

	public int addFloat(float var) {
		return rEFACTORConstantPoolGeneratorProduct.addFloat(var, this);
	}

	public int addInteger(int var) {
		return rEFACTORConstantPoolGeneratorProduct.addInteger(var, this);
	}

	public int addInterfaceMethodref(String name, String interfaceName, String retType, String paras) {
		int class_index, name_and_type_index, index;
		class_index = rEFACTORConstantPoolGeneratorProduct.addClass(interfaceName, this);
		name_and_type_index = rEFACTORConstantPoolGeneratorProduct.addMethodNameAndType(name, retType, paras, this);
		index = lookupMIFref("I_" + class_index + "_" + name_and_type_index);
		if (index == -1) {
			rEFACTORConstantPoolGeneratorProduct.ensureCapacity(this);
			items[count] = new Constant_InterfaceMethodref(class_index, name_and_type_index);
			mifRef.put("I_" + class_index + "_" + name_and_type_index, new Integer(count));
			index = count;
			count++;
		}
		return index;
	}

	public int addLong(long var) {
		return rEFACTORConstantPoolGeneratorProduct.addLong(var, this);
	}

	public int addMethodref(String name, String className, String retType, String paras) {
		int class_index, name_and_type_index, index;
		class_index = rEFACTORConstantPoolGeneratorProduct.addClass(className, this);
		name_and_type_index = rEFACTORConstantPoolGeneratorProduct.addMethodNameAndType(name, retType, paras, this);
		index = lookupMIFref("M_" + class_index + "_" + name_and_type_index);
		if (index == -1) {
			rEFACTORConstantPoolGeneratorProduct.ensureCapacity(this);
			items[count] = new Constant_Methodref(class_index, name_and_type_index);
			mifRef.put("M_" + class_index + "_" + name_and_type_index, new Integer(count));
			index = count;
			count++;
		}
		return index;
	}

	/*
	 * lookup existing field, method, interfaceMethod references
	 * in the format of [X]_[class_index]_[name_and_type_index]
	 * for method_ref X='M', field_ref X='F', interfaceMethod_ref X='I'
	 */
	private int lookupMIFref(String s) {
		Object obj = mifRef.get(s);
		if (obj == null) {
			return -1;
		} else {
			return ((Integer) obj).intValue();
		}

	}

	public int addString(String s) {
		return rEFACTORConstantPoolGeneratorProduct.addString(s, this);
	}

	public int addUtf8(String s) {
		return rEFACTORConstantPoolGeneratorProduct.addUtf8(s, this);
	}

	public static void main(String[] args) {
		ConstantPoolGenerator gen = new ConstantPoolGenerator();
		System.out.println(gen.addString("."));
		System.out.println(gen.addString("."));

	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public void setItems(ConstantPoolItem[] items) {
		this.items = items;
	}

	public ConstantPoolItem[] getItems() {
		return items;
	}

	public void ensureCapacity() {
		if (getItems().length < getCount() + 3) {
			ConstantPoolItem[] ni = new ConstantPoolItem[getItems().length + 20];
			System.arraycopy(getItems(), 0, ni, 0, getItems().length);
			setItems(ni);
		}
	}

	public int lookupUtf8(String s) {
		ConstantPoolItem item;
		for (int i = 0; i < getCount(); i++) {
			item = getItems()[i];
			if (item != null && item.tag == Constants.CONSTANT_Utf8 && ((Constant_Utf8) item).bytes.equals(s) == true) {
				return i;
			}
		}
		return -1;
	}
}