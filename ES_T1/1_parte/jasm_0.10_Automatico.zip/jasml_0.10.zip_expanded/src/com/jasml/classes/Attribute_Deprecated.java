/*
 * Author jyang
 * Created on 2006-4-3 19:22:08
 */
package com.jasml.classes;

public class Attribute_Deprecated extends Attribute{
    public Attribute_Deprecated(){
        super(Constants.ATTRIBUTE_Deprecated,0 );
    }
}
