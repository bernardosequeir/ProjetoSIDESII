package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_Synthetic;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_Synthetic
 */
public class AttributeSynthetic extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		attribute = new Attribute_Synthetic();
		return attribute;
	}
}