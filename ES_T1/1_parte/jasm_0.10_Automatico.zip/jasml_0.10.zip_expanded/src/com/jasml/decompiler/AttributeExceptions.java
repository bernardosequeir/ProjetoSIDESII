package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_Exceptions;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_Exceptions
 */
public class AttributeExceptions extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		int number_of_exceptions = in.readUnsignedShort();
		int[] exception_index_table = null;
		if (number_of_exceptions != 0) {
			exception_index_table = new int[number_of_exceptions];
			for (int counter = 0; counter < number_of_exceptions; counter++) {
				exception_index_table[counter] = in.readUnsignedShort();
			}
		}
		attribute = new Attribute_Exceptions(attribute_length, number_of_exceptions, exception_index_table);
		return attribute;
	}
}