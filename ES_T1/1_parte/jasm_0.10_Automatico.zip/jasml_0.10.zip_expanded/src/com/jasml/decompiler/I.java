package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;

public abstract class I {
	public abstract Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException;
}