package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_Deprecated;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_Deprecated
 */
public class AttributeDeprecated extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		attribute = new Attribute_Deprecated();
		return attribute;
	}
}