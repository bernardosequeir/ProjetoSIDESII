package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_LocalVariableTable;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_LocalVariableTable
 */
public class AttributeLocalvariabletable extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		int local_variable_table_length = in.readUnsignedShort();
		Attribute_LocalVariableTable.LocalVariable[] local_variable_table = null;
		if (local_variable_table_length != 0) {
			local_variable_table = new Attribute_LocalVariableTable.LocalVariable[local_variable_table_length];
			for (int counter = 0; counter < local_variable_table_length; counter++) {
				local_variable_table[counter] = javaClassParser.readLocalVariable(in);
			}
		}
		attribute = new Attribute_LocalVariableTable(attribute_length, local_variable_table_length,
				local_variable_table);
		return attribute;
	}
}