package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_Code;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_Code
 */
public class AttributeCode extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		int max_stack = in.readUnsignedShort();
		int max_locals = in.readUnsignedShort();
		int code_length = in.readInt();
		Attribute_Code.Opcode[] codes = null;
		if (code_length != 0) {
			byte[] bcode = new byte[code_length];
			in.read(bcode);
			codes = javaClassParser.parseOpcodes(bcode);
		}
		int exception_table_length = in.readUnsignedShort();
		Attribute_Code.ExceptionTableItem[] exceptionTable = null;
		if (exception_table_length != 0) {
			exceptionTable = new Attribute_Code.ExceptionTableItem[exception_table_length];
			for (int counter = 0; counter < exception_table_length; counter++) {
				exceptionTable[counter] = javaClassParser.readExceptionTableItem(in);
			}
		}
		int attributes_count = in.readUnsignedShort();
		Attribute[] attributes = null;
		if (attributes_count != 0) {
			attributes = new Attribute[attributes_count];
			for (int counter = 0; counter < attributes_count; counter++) {
				attributes[counter] = javaClassParser.readAttribute(in);
			}
		}
		attribute = new Attribute_Code(attribute_length, max_stack, max_locals, code_length, codes,
				exception_table_length, exceptionTable, attributes_count, attributes);
		return attribute;
	}
}