package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_InnerClasses;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_InnerClasses
 */
public class AttributeInnerclasses extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		int number_of_classes = in.readUnsignedShort();
		Attribute_InnerClasses.InnerClass[] innerClasses = null;
		if (number_of_classes != 0) {
			innerClasses = new Attribute_InnerClasses.InnerClass[number_of_classes];
			for (int counter = 0; counter < number_of_classes; counter++) {
				innerClasses[counter] = javaClassParser.readInnerClass(in);
			}
		}
		attribute = new Attribute_InnerClasses(attribute_length, number_of_classes, innerClasses);
		return attribute;
	}
}