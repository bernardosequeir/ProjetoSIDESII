package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_LineNumberTable;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_LineNumberTable
 */
public class AttributeLinenumbertable extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		int line_number_table_length = in.readUnsignedShort();
		Attribute_LineNumberTable.LineNumber[] line_number_table = null;
		if (line_number_table_length != 0) {
			line_number_table = new Attribute_LineNumberTable.LineNumber[line_number_table_length];
			for (int counter = 0; counter < line_number_table_length; counter++) {
				line_number_table[counter] = javaClassParser.readLineNumber(in);
			}
		}
		attribute = new Attribute_LineNumberTable(attribute_length, line_number_table_length, line_number_table);
		return attribute;
	}
}