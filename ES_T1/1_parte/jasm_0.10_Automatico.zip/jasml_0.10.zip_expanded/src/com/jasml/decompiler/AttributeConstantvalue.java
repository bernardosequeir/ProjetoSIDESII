package com.jasml.decompiler;


import com.jasml.classes.Attribute;
import java.io.DataInputStream;
import java.io.IOException;
import com.jasml.classes.Attribute_ConstantValue;

/**
 * @see com.jasml.classes.Constants#ATTRIBUTE_ConstantValue
 */
public class AttributeConstantvalue extends I {
	public Attribute readAttribute(Attribute attribute, DataInputStream in, int attribute_length,
			JavaClassParser javaClassParser) throws IOException {
		attribute = new Attribute_ConstantValue(attribute_length, in.readUnsignedShort());
		return attribute;
	}
}