package com.jasml.decompiler;

import java.io.DataInputStream;

import com.jasml.classes.Attribute;
import com.jasml.classes.ConstantPool;
import com.jasml.classes.Field;
import com.jasml.classes.Method;

public class JavaClassParserData {
	public DataInputStream in;
	public int magic;
	public int minor_Version;
	public int major_Version;
	public short constant_Pool_Count;
	public ConstantPool constantPool;
	public short access_flags;
	public int this_class;
	public int super_class;
	public int interfaces_count;
	public int[] interfaces;
	public int fields_count;
	public Field[] fields;
	public int methods_count;
	public Method[] methods;
	public int attributes_count;
	public Attribute[] attributes;

	public JavaClassParserData() {
	}
}