package com.jasml.compiler;

import java.util.HashMap;

import com.jasml.classes.ConstantPoolItem;

public class ConstantPoolGeneratorData {
	public ConstantPoolItem[] items;
	public int count;
	public HashMap classes;
	public HashMap nameTypes;
	public HashMap mifRef;
	public HashMap strings;

	public ConstantPoolGeneratorData(int count, HashMap classes, HashMap nameTypes, HashMap mifRef, HashMap strings) {
		this.count = count;
		this.classes = classes;
		this.nameTypes = nameTypes;
		this.mifRef = mifRef;
		this.strings = strings;
	}
}